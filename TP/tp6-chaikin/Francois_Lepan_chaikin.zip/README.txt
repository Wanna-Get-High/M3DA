Francois Lepan

Tout est fait. Les commandes sont disponibles dans l'application 
en cliquant sur le troisième bouton.