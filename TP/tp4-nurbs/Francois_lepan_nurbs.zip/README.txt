Francois Lepan

Je suis arrive jusque'a la question 10 faire une animation.

Tout fonctionne jusque la.
Les boutons sur la gauche ne sont pas utilises.

Fonctionnement :

	un clique gauche rajoute un point de controle
	un clique droit enleve le dernier point rajoute

	q permet d'augmenter le degree de la courbe
	w permet de reduire le degree de la courbe